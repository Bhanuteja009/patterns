/**
 * 
 */
package question10;

import java.io.FileNotFoundException;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	public void method1() throws FileNotFoundException {
		
	}
	
	
}

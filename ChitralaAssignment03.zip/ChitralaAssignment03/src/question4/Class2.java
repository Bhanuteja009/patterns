/**
 * 
 */
package question4;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class2 extends Class1 {
	
	//Cannot override the static method
	
//	@Override
//	public static void method1() {
//		System.out.println("sub static method");
//	}
	
	//Cannot override the private method
	
//	@Override
//	private void method2() {
//		System.out.println("sub static method");
//	}

}

/**
 * 
 */
package question2;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class2 extends Class1 {
	
	@Override
	protected void method1() {
		System.out.println("This is sub class protected scope method"
				+ " that is changed from default ");
	}
	
	
	@Override
	public void method2() {
		System.out.println("This is sub class public scope method"
				+ " that is changed from protected ");
	}
	
	@Override
	public void method3() {
		System.out.println("This is sub class public scope method");
	}

}

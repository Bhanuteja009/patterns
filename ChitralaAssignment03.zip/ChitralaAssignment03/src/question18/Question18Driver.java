/**
 * 
 */
package question18;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question18Driver implements Runnable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Question18Driver qd=new Question18Driver();
		Thread t=new Thread(qd);
		
		t.start();
		
		t.start();
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("in the run method");
		
	}

}

package question5;

public class Question5Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// using StringBuffer
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("Hi, ");
		stringBuffer.append("This is ");
		stringBuffer.append("Bhanuteja");
		String s1 = stringBuffer.toString();
		System.out.println("StringBuffer: " + s1);

		// using StringBuilder
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("Hi, ");
		stringBuilder.append("This is ");
		stringBuilder.append("Bhanuteja");
		String s2 = stringBuilder.toString();
		System.out.println("StringBuilder: " + s2);
	}

}

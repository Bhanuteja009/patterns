/**
 * 
 */
package question22;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {

	private final String studentId;
	
	private final String courseId ;

	/**
	 * @param studentId
	 * @param courseId
	 */
	public Class1(String studentId, String courseId) {
		super();
		this.studentId = studentId;
		this.courseId = courseId;
	}

	/**
	 * @return the studentId
	 */
	public String getStudentId() {
		return studentId;
	}

	/**
	 * @return the courseId
	 */
	public String getCourseId() {
		return courseId;
	}
	
	
	
	
	
	

}

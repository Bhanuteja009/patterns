/**
 * 
 */
package question19;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class ThreadDemo extends Thread {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThreadDemo td=new ThreadDemo();
		td.start();

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("in the run method");
		
	}
}

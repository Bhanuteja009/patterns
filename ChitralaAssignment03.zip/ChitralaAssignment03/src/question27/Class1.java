/**
 * 
 */
package question27;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	private static Class1 obj=null;
	
	private Class1() {
		
	}

	
	public synchronized Class1 getObject() {
		
		if(obj==null) {
			return new Class1();
			
		}else {
			return obj;
		}
	}
}

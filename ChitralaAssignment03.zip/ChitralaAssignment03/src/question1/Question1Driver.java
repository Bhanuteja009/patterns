/**
 * 
 */
package question1;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question1Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Integer data types");
		System.out.println(calculate(5, 6));
		
		System.out.println("Double data types");
		System.out.println(calculate(5.4, 6.3));
		
	}
	
	
    static <T> T calculate(T a, T b){
		
    	if(a instanceof Integer) {
    	
    		return (T) Integer.valueOf(((Integer) a).intValue() + ((Integer) b).intValue());
    	}
    	else if(a instanceof Double){
    		return (T) Double.valueOf(((Double) a).doubleValue() + ((Double) b).doubleValue());
    	}
		
    	return null;
	}
	

}

package question6;

public class Question6Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Hi this is Chitrala,"; // Immutable
		s1 = s1 + " Bhanuteja."; // A new string object is created
		
		System.out.println(s1);

		StringBuilder s2 = new StringBuilder("Hi this is Chitrala,"); // Mutable
		s2.append(" Bhanuteja."); // Contents modified in-place
		System.out.println(s2);
	}

}

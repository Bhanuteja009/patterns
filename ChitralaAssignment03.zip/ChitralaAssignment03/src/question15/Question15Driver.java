/**
 * 
 */
package question15;

import java.util.HashMap;
import java.util.Hashtable;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question15Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<String, Integer> htable = new Hashtable<String, Integer>();
		htable.put("Car", 4);
		htable.put("Bike", 2);
		htable.put("Truck", 6);

		System.out.println(htable);
		
		HashMap<String, Integer> hMap = new HashMap<String, Integer>();
		hMap.put("Car", 4);
		hMap.put("Bike", 2);
		hMap.put("Truck", 6);
		
		System.out.println(hMap);

	}

}

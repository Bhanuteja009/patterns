/**
 * 
 */
package question20;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question20Driver implements Runnable{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Question20Driver qd=new Question20Driver();
		
		Thread t=new Thread(qd);
		
		System.out.println(t.getState());
		
		t.start();
		
		System.out.println(t.getState());
		
		try {
			
			t.sleep(100);
			//System.out.println(t.getState());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("in catch block");
		}

		
		try {
			t.wait();
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("in catch block");
		}
		
		t.interrupt();
		
		System.out.println(t.getState());
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("in the run method");
		
	}

}

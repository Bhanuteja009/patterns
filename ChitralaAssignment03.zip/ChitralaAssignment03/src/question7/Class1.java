/**
 * 
 */
package question7;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {

	// Cannot declare constructor as final
//	final public Class1() {
//		// TODO Auto-generated constructor stub
//	}
	
	
	
}

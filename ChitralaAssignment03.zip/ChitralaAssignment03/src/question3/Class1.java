/**
 * 
 */
package question3;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	public Class1 method1() {
		System.out.println("This is super class method");
		return new Class1();
	}
	
	
}

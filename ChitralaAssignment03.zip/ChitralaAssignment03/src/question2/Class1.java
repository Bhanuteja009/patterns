/**
 * 
 */
package question2;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	void method1() {
		System.out.println("This is super default scope method");
	}
	
	protected void method2() {
		System.out.println("This is super class protected scope method");
	}

	public void method3() {
		System.out.println("This is super class public scope method");
	}
}

/**
 * 
 */
package question12;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	public void method1() {
		
		final int a= 10;
		
		//a=20; // cannot override the value
		
		try {
			//code that may throw exception
		}finally {
			//This block is used is always executed
		}
		
	}
	
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
	
	
}

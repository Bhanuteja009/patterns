/**
 * 
 */
package question25;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question25Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> names=(ArrayList<String>) Arrays.asList("bhanu","anil","zaheer");
		
		//Lambda
		Collections.sort(names, (s1,s2)->{
			return s1.compareTo(s2);
		});
		
		System.out.println(names);
		
		//forEach
		names.forEach(name->System.out.println("names is"+name));
		
		//Streams
		names.stream().filter(n->n.startsWith("b"));
	}
	
	

}

/**
 * 
 */
package question3;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class2 extends Class1 {
	
	@Override
	public Class2 method1() {
		System.out.println("This is sub class method ");
		return new Class2();
	}
	

}

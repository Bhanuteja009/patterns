/**
 * 
 */
package question17;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class FailSafeDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CopyOnWriteArrayList<Integer> numbers = new CopyOnWriteArrayList<>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
        Iterator<Integer> itr = numbers.iterator();
        while (itr.hasNext()) {
            Integer number = itr.next();
            System.out.println(number);
            numbers.remove(0); // No Concurrent modification exception
        }
	}

}

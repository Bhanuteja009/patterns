/**
 * 
 */
package question13;

import java.util.ArrayList;
import java.util.Vector;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question13Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Vector is synchronized.
		Vector<String> v = new Vector<String>();
		v.add("apple");
		v.add("banana");
		v.add("orange");

		// ArrayList is not synchronized by default.
		ArrayList<String> al = new ArrayList<String>();
		al.add("apple");
		al.add("banana");
		al.add("orange");

	}

}

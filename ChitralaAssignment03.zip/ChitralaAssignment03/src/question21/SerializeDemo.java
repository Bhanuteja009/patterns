/**
 * 
 */
package question21;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


/**
 * @author Bhanuteja Chitrala
 *
 */
public class SerializeDemo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String studentId;
	private String courseId;
	
	

	/**
	 * @param studentId
	 * @param courseId
	 */
	public SerializeDemo(String studentId, String courseId) {
		super();
		this.studentId = studentId;
		this.courseId = courseId;
	}



	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	/**
	 * @return the studentId
	 */
	public String getStudentId() {
		return studentId;
	}



	/**
	 * @return the courseId
	 */
	public String getCourseId() {
		return courseId;
	}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			// Serialization
			SerializeDemo sdemo = new SerializeDemo("s5436", "44564");
			FileOutputStream outStream = new FileOutputStream("Input.ser");
			ObjectOutputStream output = new ObjectOutputStream(outStream);
			output.writeObject(sdemo);
			output.close();
			output.close();

			// Deserialization
			FileInputStream inputStream = new FileInputStream("Input.ser");
			ObjectInputStream input = new ObjectInputStream(inputStream);
			SerializeDemo deserializedDriver = (SerializeDemo) input.readObject();
			input.close();
			inputStream.close();
			System.out.println("StudentId: " + deserializedDriver.getStudentId());
			System.out.println("CourseId: " + deserializedDriver.getCourseId());
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}

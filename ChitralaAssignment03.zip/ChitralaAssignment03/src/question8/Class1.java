/**
 * 
 */
package question8;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	public void method1() {
		
		try {
			System.out.println("try block");
		}
		finally {
			System.out.println("finally block");
		}
	}
	
}

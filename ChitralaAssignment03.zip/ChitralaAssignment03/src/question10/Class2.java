/**
 * 
 */
package question10;

import java.io.IOException;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class2 extends Class1 {
	
	@Override
	public void method1() throws IOException{
		
	}
	

}

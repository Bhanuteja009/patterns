/**
 * 
 */
package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {

	public void method1() {
		
		
		ArrayList<Integer> al = new ArrayList<>();

		// Synchronized
		List<Integer> syncAL = Collections.synchronizedList(al);
		
		synchronized (al) {
			// Access the list here
		}

		// Thread-safe by design
		List<Integer> cowAL = new CopyOnWriteArrayList<>();
}
	
}

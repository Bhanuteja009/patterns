/**
 * 
 */
package question2;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question2Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class1 cl1=new Class1();
		Class1 cl2=new Class2();
		System.out.println("Default scope demo");
		
		cl1.method1();	
		
		cl2.method1();
		
		System.out.println("\nProtected scope demo");
		cl1.method2();	
		
		cl2.method2();
		
		
		System.out.println("\nPublic scope demo");
		cl1.method2();	
		
		cl2.method2();
		

	}

}

/**
 * 
 */
package question4;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Class1 {
	
	
	
	public static void method1() {
		System.out.println("Superclass static method");
	}

	private void method2() {
		System.out.println("Superclass static method");
	}
}

/**
 * 
 */
package question9;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Bhanuteja Chitrala
 *
 */
public class Question9Driver {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub

		try (BufferedReader reader = new BufferedReader(new FileReader("input.txt"))) {
			// Code that reads from the file using the reader
		}
	}

}
